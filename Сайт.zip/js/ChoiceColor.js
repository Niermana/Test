var imgBig = document.getElementById("Big-photo");
var textBig = document.getElementById("textBig");
var image = new Array("Ирландский дуб", "Дуб светлый", "Орех золотой", "Дуб молочный", "Красное дерево", "Береза", "Сосна светлая"); 
function ChoiceIMG(id, num) {
	var imageColor = document.getElementById(id);
	imgBig.src = "img/Big-photo"+num+".png";
	textBig.innerHTML = image[num-1];
	document.getElementById("choice").src = "img/icn.png";
}